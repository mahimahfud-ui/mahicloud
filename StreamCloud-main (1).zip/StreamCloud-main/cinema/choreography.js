// Scroll choreography: scroll → shared state, section reveals, hero exit.
// (The old per-column card drift was removed: it knocked the grid out of alignment and cost scroll performance.)
import { state, clamp } from './state.js';

export function initChoreography({ invalidate }) {
  const root = document.documentElement;
  const hero = document.getElementById('top');
  const finale = document.getElementById('finale');
  let vh = innerHeight, queued = false;

  // ---- reveals: add `.in` once when something first enters the viewport ----
  // The catalog re-renders (mode switch, filters, search), so new nodes are picked up by a MutationObserver.
  const hasIO = 'IntersectionObserver' in window;
  const revealIO = hasIO ? new IntersectionObserver(entries => entries.forEach(en => {
    if (en.isIntersecting) { en.target.classList.add('in'); revealIO.unobserve(en.target); }
  }), { rootMargin: '0px 0px -6% 0px', threshold: 0.05 }) : null;

  const seen = new WeakSet();
  function watch(scope) {
    scope.querySelectorAll('.row-head, .card, .finale-in > *').forEach(el => {
      if (seen.has(el)) return; seen.add(el);
      revealIO ? revealIO.observe(el) : el.classList.add('in');
    });
  }
  watch(document);
  const main = document.querySelector('main');
  if (main && 'MutationObserver' in window) {
    new MutationObserver(() => watch(main)).observe(main, { childList: true, subtree: true });
  }
  // ---- main scroll step (rAF-throttled, passive) ----
  function step() {
    queued = false;
    const y = scrollY, docH = root.scrollHeight;
    state.scroll = y;
    state.hero = clamp(y / (vh * .9));
    state.finale = clamp((vh - finale.getBoundingClientRect().top) / (vh * .85));
    state.pageP = clamp(y / Math.max(1, docH - vh));
    hero.style.setProperty('--hp', state.hero.toFixed(3));
    root.classList.toggle('at-finale', state.finale > .2);
    if (state.reduced) invalidate();
  }
  const queue = () => { if (!queued) { queued = true; requestAnimationFrame(step); } };
  addEventListener('scroll', queue, { passive: true });
  addEventListener('resize', () => { vh = innerHeight; queue(); });
  step();
  return { refresh: queue };
}