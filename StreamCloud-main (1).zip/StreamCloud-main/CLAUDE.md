# Claude Guide — MahiFlix / StreamCloud

This is the public GitHub repository for MahiFlix, a static directory of movie and web-series websites, streaming apps, and music apps hosted from the repository root.

- Repository: https://github.com/mahimahfud-ui/StreamCloud
- Default branch: `main`
- Main page (raw file): https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/index.html
- Complete tracked-file map (GitHub API): https://api.github.com/repos/mahimahfud-ui/StreamCloud/git/trees/main?recursive=1

## Important: GitHub web pages may block automated browsing

If a URL such as `github.com/mahimahfud-ui/StreamCloud/tree/main` or a `/blob/main/` page returns an automated-access, rate-limit, or security-block message, **do not conclude that the repository is inaccessible and do not ask the user to paste the entire code**.

Use one of these alternatives instead:

1. Read one file from its raw URL:
   `https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/PATH/TO/FILE`
2. List a directory using the GitHub Contents API:
   `https://api.github.com/repos/mahimahfud-ui/StreamCloud/contents/PATH?ref=main`
3. List the entire repository tree:
   `https://api.github.com/repos/mahimahfud-ui/StreamCloud/git/trees/main?recursive=1`
4. Read a file through the Contents API:
   `https://api.github.com/repos/mahimahfud-ui/StreamCloud/contents/PATH?ref=main`

Replace `PATH` with the real path; preserve case. Prefer small, targeted file reads. If a raw/API endpoint itself fails, report that specific failure honestly.

## Project map

- `index.html` — homepage and catalog UI. It contains the website/app catalog, search/filter/sort behavior, cards, details dialog, and metadata.
- `cinema/` — separated cinematic interaction and presentation modules:
  - `main.js`
  - `scene.js`
  - `state.js`
  - `interactions.js`
  - `choreography.js`
  - `cinema.css`
  - `portal.js` / `portal.css` — the hero "Channel Jump" portal: a tilting canvas window showing a reel of the *other* collection; activating it expands to full screen, switches Websites/Apps through the page's own `.mode` buttons, then irises open onto the catalog. Generated from the catalog + local logos only (no remote media). Reduced-motion users get an instant jump.
  - `preloader.js` — real-progress counter inside the existing `#intro` overlay; logo glides into the nav slot. `index.html` keeps a 4.5 s hard failsafe.
- `polish.css` / `polish.js` — final presentation layer (loaded last): single-row nav, calm hero, even card grid, spring-eased tabs and dialogs, scroll progress bar, back-to-top, `/` or Ctrl/Cmd+K search shortcut, hero stats counted from the real catalog, dialog focus trap. Rules: keep it additive, wrap motion in `prefers-reduced-motion`, never reintroduce the per-column card drift or 3D tilt (they made the grid ragged). `polish.js` flags typing/filter/star renders with `.p-soft` so entrance animations don't replay on every keystroke.
- Note: `cinema/portal.js` is **not** wired into `index.html` any more (only `portal.css` is linked). Treat it as dormant code.
- `assets/logos/` — locally stored SVG marks for catalog entries.
- `logo-manifest.js` — mapping of site domains to local logo assets.
- `s-logo-v1.svg` — primary cinematic S lettermark used across the site.
- `manifest.webmanifest`, `sw.js` — installable web-app manifest and offline shell.
- `link-status.json` — output consumed by the UI for the most recent scheduled external-link checks.
- `scripts/check_links.py` — conservative external-link health checker.
- `scripts/fetch-logos.mjs` — helper for fetching/refreshing logo assets.
- App "Download" buttons link to each app's official page (or GitHub Releases). The old `/download/app/*` routes needed a server that no longer exists; do not reintroduce them.
- `vendor/three.module.min.js` — bundled third-party library; avoid editing minified vendor code unless explicitly necessary.
- `.github/workflows/deploy-pages.yml` — GitHub Pages deployment.
- `.github/workflows/check-links.yml` — scheduled/manual link-check workflow.
- `og-image.svg` — social preview artwork.

## Working rules

1. Inspect the relevant current files before making changes; work against the latest `main` contents.
2. Preserve the existing dark cinematic visual identity, project-specific features, data and responsive behavior unless the user explicitly asks for a redesign.
3. Make targeted changes. Do not replace the site with a new scaffold or delete unrelated assets.
4. The repository is a static site served from a GitHub Pages **project URL** (`/StreamCloud/`). Never use root-absolute paths (`/vendor/…`, `/assets/…`); use relative paths, and note that CSS `url()` and JS `import` resolve relative to their own file.
5. Do not invent ratings, live availability, test results, dates, or link-health statuses. The directory score and ad-level labels are editorial estimates unless real evidence says otherwise.
6. Link-check results must treat temporary failures, rate limits and access restrictions as `unknown`, not automatically as a dead link.
7. Keep third-party licenses. Do not edit `vendor/three.module.min.js` to make routine changes.
8. Never commit API keys, passwords, tokens, private user data, or environment secrets.
9. After JavaScript edits, check syntax; after UI edits, check desktop/mobile styles and key interactions. Summarize exact files changed and what was actually verified.

## Useful direct file links

- [Main HTML](https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/index.html)
- [Cinema main module](https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/cinema/main.js)
- [Cinema styles](https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/cinema/cinema.css)
- [Logo manifest](https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/logo-manifest.js)
- [Link-check script](https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/scripts/check_links.py)
- [Link status data](https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/link-status.json)
- [Pages deployment workflow](https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/.github/workflows/deploy-pages.yml)
