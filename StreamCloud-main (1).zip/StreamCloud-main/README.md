# MahiFlix

A curated movie and series directory by Mahi. This repository is public and the site is deployed from its root using GitHub Pages.

## Source and repository links

- [Open the live site](https://mahimahfud-ui.github.io/StreamCloud/)
- [GitHub repository](https://github.com/mahimahfud-ui/StreamCloud)
- [Main source HTML (direct/raw)](https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/index.html)
- [Full repository file map (GitHub API)](https://api.github.com/repos/mahimahfud-ui/StreamCloud/git/trees/main?recursive=1)
- [Claude-specific project guide](./CLAUDE.md)
- [General coding-agent guide](./AGENTS.md)

## Project structure

| Path | Purpose |
|---|---|
| `index.html` | Main site, catalog UI, search, filters, sorting and listing detail dialog |
| `cinema/` | Cinematic scene, state, interaction and choreography modules, plus the hero portal (`portal.js`) and preloader (`preloader.js`) |
| `polish.css`, `polish.js` | Final premium UI layer: layout, motion, scroll progress, search shortcut, hero stats |
| `assets/logos/` | Local SVG logos |
| `logo-manifest.js` | Domain-to-logo mapping |
| `manifest.webmanifest` | Installable web app metadata |
| `sw.js` | Offline catalog shell |
| `link-status.json` | Latest link-check snapshot consumed by the UI |
| `scripts/check_links.py` | Conservative external-link checker |
| `scripts/fetch-logos.mjs` | Logo helper |
| `vendor/` | Third-party library and license |
| `.github/workflows/` | GitHub Pages deployment and link-check workflows |
| `og-image.svg` | Social preview image |

## When a browser cannot open GitHub pages

Some automated browsing tools block GitHub's `tree/main` or `blob/main` HTML views. This alone does not mean the public repository is inaccessible. Use a direct raw source URL such as:

`https://raw.githubusercontent.com/mahimahfud-ui/StreamCloud/main/index.html`

For directories or the complete tree, use the GitHub API links above. Do not ask the user to paste source that is already present in this public repository unless direct raw/API access also fails.

## Development notes

Keep the existing dark cinematic design and data. Prefer targeted changes, verify JavaScript syntax after edits, preserve the vendor license, and avoid claiming a deployment or live link check is complete until it has been verified.

## Movies & Web Series recommendations
- [Reusable ChatGPT prompt for Movies, Series, Websites, and Apps](./CHATGPT-STREAMCLOUD-PROMPT.md)


Recommendations are maintained manually in `data/recommendations.json`. The Website list starts empty and only includes URLs you explicitly supply. There is **no TMDB/OMDb metadata API, API key, repository secret, or build-time metadata fetch**.

- Add movie objects to `movies` and TV/web-series objects to `series`.
- Useful fields: `title` (required), `year`, `poster` (direct HTTPS image URL or a local image path), `genres`, `rating` (optional `{"source":"IMDb","value":8.5}`), `overview`, `imdbId`, `runtime` for movies, and `seasonCount` / `episodeCount` for series.
- `note`, `originalTitle`, `status`, custom `links`, and `seasonList` are optional.
- To add or edit a recommendation, update only `data/recommendations.json` and push to `main`. The existing GitHub Pages workflow deploys the data along with the site.
- With repository access connected in ChatGPT, you can simply ask: **“Add [title] ([year]) to StreamCloud recommendations as a movie/web series, verify the basic details and poster URL, update `data/recommendations.json`, and commit to `main`.”**

Ratings, summaries and season counts are manually maintained snapshots and may need edits over time. Poster images are loaded from the URLs recorded in the JSON file.
