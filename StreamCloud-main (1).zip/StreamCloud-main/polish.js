/* StreamCloud polish layer (behaviour). Loaded last, never required: every block is isolated
   so a failure here cannot affect the catalog, search, favourites or dialogs. */
(function () {
  "use strict";
  var doc = document, root = doc.documentElement;
  var reduced = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var $ = function (s, r) { return (r || doc).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || doc).querySelectorAll(s)); };
  var safe = function (fn) { try { fn(); } catch (e) { if (window.console) console.warn("[polish]", e); } };

  /* 1 ─ Scroll progress bar + back-to-top button (one rAF-throttled passive listener) */
  safe(function () {
    var bar = doc.createElement("div"); bar.id = "scProgress"; bar.setAttribute("aria-hidden", "true");
    var top = doc.createElement("button"); top.id = "scTop"; top.type = "button"; top.setAttribute("aria-label", "Back to top");
    top.innerHTML = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.6' stroke-linecap='round' stroke-linejoin='round' aria-hidden='true'><path d='M12 19V5M5 12l7-7 7 7'/></svg>";
    doc.body.appendChild(bar); doc.body.appendChild(top);
    top.addEventListener("click", function () { window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" }); });
    var queued = false;
    function step() {
      queued = false;
      var max = Math.max(1, root.scrollHeight - innerHeight), y = window.scrollY || 0;
      bar.style.setProperty("--p", Math.min(1, y / max).toFixed(4));
      top.classList.toggle("show", y > innerHeight * 0.9);
    }
    addEventListener("scroll", function () { if (!queued) { queued = true; requestAnimationFrame(step); } }, { passive: true });
    addEventListener("resize", step, { passive: true });
    step();
  });

  /* 2 ─ Search: "/" or Ctrl/Cmd+K focuses it from anywhere, with a visible shortcut hint */
  safe(function () {
    var box = $("#search"), input = $("#q");
    if (!box || !input) return;
    var hint = doc.createElement("kbd"); hint.className = "p-kbd"; hint.setAttribute("aria-hidden", "true"); hint.textContent = "/";
    box.appendChild(hint);
    input.setAttribute("aria-label", "Search websites and apps");
    addEventListener("keydown", function (e) {
      var t = e.target, typing = t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
      var combo = (e.key === "k" || e.key === "K") && (e.ctrlKey || e.metaKey);
      if (!(combo || (e.key === "/" && !typing && !e.ctrlKey && !e.metaKey && !e.altKey))) return;
      if ($(".detail-modal.open,.wl-modal.open")) return;
      e.preventDefault();
      box.classList.add("open"); input.focus(); input.select();
    });
  });

  /* 3 ─ Hero stats, counted from the real catalog (nothing invented) */
  safe(function () {
    var C = window.MAHIFLIX_CATALOG, desc = $("#heroDesc");
    if (!C || !desc || $(".p-stats")) return;
    var apps = C.apps || [];
    var data = [
      [(C.sites || []).length, "Websites"],
      [apps.filter(function (a) { return a.appType === "movie"; }).length, "Movie apps"],
      [apps.filter(function (a) { return a.appType === "music"; }).length, "Music apps"]
    ].filter(function (x) { return x[0] > 0; });
    if (!data.length) return;
    var ul = doc.createElement("ul"); ul.className = "p-stats"; ul.setAttribute("aria-label", "Directory size");
    ul.innerHTML = data.map(function (x) { return "<li><b data-n='" + x[0] + "'>" + (reduced ? x[0] : 0) + "</b><span>" + x[1] + "</span></li>"; }).join("");
    desc.insertAdjacentElement("afterend", ul);
    if (reduced) return;
    var started = false;
    function run() {
      if (started) return; started = true;
      var t0 = performance.now(), D = 1100;
      (function tick(now) {
        var p = Math.min(1, (now - t0) / D), e = 1 - Math.pow(1 - p, 3);
        $$("b[data-n]", ul).forEach(function (b) { b.textContent = Math.round(Number(b.dataset.n) * e); });
        if (p < 1) requestAnimationFrame(tick);
      })(t0);
    }
    // wait for the intro overlay to finish so the count is actually seen
    if (root.classList.contains("intro-on")) {
      doc.addEventListener("mahiflix:intro-end", function () { setTimeout(run, 250); }, { once: true });
      setTimeout(run, 6000);
    } else run();
  });

  /* 4 ─ Keep rendering calm: typing, filtering and starring must not replay card entrances.
         The page re-renders a view on every keystroke; flag those renders as "soft". */
  safe(function () {
    var views = [$("#sitesView"), $("#appsView")].filter(Boolean);
    function soften() { views.forEach(function (v) { v.classList.add("p-soft"); }); }
    function harden() { views.forEach(function (v) { v.classList.remove("p-soft"); }); }
    ["#q", "#adFilter", "#sortSelect"].forEach(function (s) {
      var el = $(s); if (!el) return;
      el.addEventListener("input", soften, true); el.addEventListener("change", soften, true);
    });
    doc.addEventListener("click", function (e) {
      if (e.target.closest(".mode")) harden();                       // switching category = full, staggered entrance
      else if (e.target.closest(".filter-chip,.sc-chip,.sc-reset,#detailFavorite")) soften();
    }, true);
  });

  /* 5 ─ Dialog focus management: keep Tab inside an open dialog */
  safe(function () {
    doc.addEventListener("keydown", function (e) {
      if (e.key !== "Tab") return;
      var dlg = $(".detail-modal.open .detail-panel,.wl-modal.open .wl-panel");
      if (!dlg) return;
      var f = $$("a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex='-1'])", dlg)
        .filter(function (n) { return n.offsetParent !== null; });
      if (!f.length) { e.preventDefault(); dlg.focus(); return; }
      var first = f[0], last = f[f.length - 1], a = doc.activeElement;
      if (!dlg.contains(a)) { e.preventDefault(); first.focus(); }
      else if (e.shiftKey && (a === first || a === dlg)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && a === last) { e.preventDefault(); first.focus(); }
    });
  });

  /* 6 ─ Small accessibility fixes for the generated markup */
  safe(function () {
    var nav = $("#nav"); if (nav) nav.setAttribute("aria-label", "Primary");
    var sv = $("#sitesView"), av = $("#appsView");
    if (sv) sv.setAttribute("role", "tabpanel");
    if (av) av.setAttribute("role", "tabpanel");
    $$(".mode").forEach(function (b) { if (!b.id) b.id = "tab-" + b.dataset.mode; });
    var yr = $("#yr"); if (yr && !yr.textContent) yr.textContent = new Date().getFullYear();
  });
})();
